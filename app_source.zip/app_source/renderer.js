// This file is required by the index.html file and will
// be executed in the renderer process for that window.
// All of the Node.js APIs are available in this process.

//

const remote = require('electron').remote;
const os = require('os');
const storage = require('electron-json-storage');

var prev_port;
var myPort;

var R = 0;
var G = 0;
var B = 0;

// pull saved variables out of previous instances of the app

storage.get('R', function(error, data) {
  if (error) throw error;
  R = data;
  setupColor('R', data);
});

storage.get('G', function(error, data) {
  if (error) throw error;
  G = data;
  setupColor('G', data);
});

storage.get('B', function(error, data) {
  if (error) throw error;
  B = data;
  setupColor('B', data);
});

storage.get('prev_port', function(error, data) {
  if (error) throw error;

  //console.log('derp: '+data);
  if(data) {
    try{
      myPort = new SerialPort(data, 9600);
      setTimeout(function () {
        myPort.write("R:" + R.toString());
        myPort.write("G:" + G.toString());
        myPort.write("B:" + B.toString());
        console.log(R.toString() + ", " + G.toString() + ", " + B.toString());
      }, 2000);
    }
    catch(err){

    }
  }
});


// serial port initialization:
var SerialPort = require('serialport'); // include the serialport library

var ports_list = document.getElementById("ports-list");
//ports_list.innerHTML = SerialPort.list();

SerialPort.list(function (err, ports) {
  ports.forEach(function(port) {
    var ports_list = document.getElementById("ports-list");
    var node = document.createElement("option");
    var textnode = document.createTextNode(port.comName);
    node.appendChild(textnode);
    ports_list.appendChild(node);
  });
});

var portName = '/dev/cu.usbmodem14631'; // get the port name from the command line
//console.log("set port: " + prev_port);
//var myPort = new SerialPort(prev_port, 9600);

// these are the definitions for the serial events:
//myPort.on('open', openPort); // called when the serial port opens

// function openPort() {
//     var brightness = 0; // the brightness to send for the LED
//     console.log('port open');
//
//     // since you only send data when the port is open, this function
//     // is local to the openPort() function:
//     function sendData() {
//          // convert the value to an ASCII string before sending it:
//          myPort.write("R:" + brightness.toString());
//          console.log("R:" + brightness.toString());
//          // increment brightness by 10 points. Rollover if > 255:
//          if (brightness < 255) {
//               brightness = 255;
//          } else {
//               brightness = 0;
//          }
//     }
//     myPort.on('data', function(data) {
//       console.log("data: " + data.toString());
//     });
//     // set an interval to update the brightness 2 times per second:
//     setInterval(sendData, 2000);
// }


var slider1 = document.getElementById("R_slider");
var slider2 = document.getElementById("G_slider");
var slider3 = document.getElementById("B_slider");

var output1 = document.getElementById("val1");
var output2 = document.getElementById("val2");
var output3 = document.getElementById("val3");

var serial_port_ = document.getElementById("ports_list");

output1.innerHTML = slider1.value;
output2.innerHTML = slider2.value;
output3.innerHTML = slider3.value;

// Update the current slider value (each time you drag the slider handle)
slider1.oninput = function() {
  R = this.value;
  output1.innerHTML = "R:" + this.value.toString();
  myPort.write("R:" + this.value.toString());
  console.log("R:" + this.value.toString());
}
slider2.oninput = function() {
  G = this.value;
  output2.innerHTML = "G:" + this.value.toString();
  myPort.write("G:" + this.value.toString());
    console.log("G:" + this.value.toString());
}
slider3.oninput = function() {
  B = this.value;
  output3.innerHTML = "B:" + this.value.toString();
  myPort.write("B:" + this.value.toString());
  console.log("B:" + this.value.toString());
}

var close_button = document.getElementById("close-button");

document.addEventListener('DOMContentLoaded',function() {
  ports_list.onchange = serialPortChange;
},false);

function setupColor(color, value) {
  //myPort.write(color + ":" + value.toString());
  document.getElementById(color + "_slider").value = value;
  output1.innerHTML = "R" + slider1.value;
  output2.innerHTML = "G" + slider2.value;
  output3.innerHTML = "B" + slider3.value;
}

function serialPortChange() {
  var idx = ports_list.selectedIndex;
  var which = ports_list.options[idx].value;
  console.log(which);
  console.log(myPort);
  try{
    myPort.close()
  }
  catch(er){
    console.log("error of some sort");
  }
  setTimeout(function () {

    myPort = new SerialPort(which, 9600);

    storage.set('prev_port', which, function(error) {
      if (error) throw error;
    });

  }, 500);
  console.log(myPort);

  setTimeout(function () {


    myPort.write('main screen turn on', function(err) {
      if (err) {
        return console.log('Error on write: ', err.message);
      }
      console.log('message written');
    });

    // Open errors will be emitted as an error event
    myPort.on('error', function(err) {
      console.log('Error: ', err.message);
    })
  }, 500);
}

close_button.addEventListener("mouseover", function( event ) {
  // highlight the mouseover target
  event.target.src = "close_hover.png";

}, false);

close_button.addEventListener("mouseout", function( event ) {
  // highlight the mouseover target
  event.target.src = "close_normal.png";

}, false);

close_button.addEventListener("mousedown", function( event ) {
  // highlight the mouseover target
  event.target.src = "close_click.png";

}, false);

close_button.addEventListener("click", function( event ) {
  // highlight the mouseover target
  event.target.src = "close_hover.png";
  var window = remote.getCurrentWindow();
  window.close();

}, false);

window.addEventListener("focus", function(event) {
  close_button.style.height = "12px";
  close_button.style.width = "12px";
  close_button.style.margin = "0px";
  //close_button.src = "close_normal.png";
}, false);

window.addEventListener("blur", function(event) {
  close_button.style.height = "0px";
  close_button.style.width = "0px";
  close_button.style.margin = "5px";
  //close_button.src = "close_inactive.png";
}, false);

document.getElementById('close-button').ondragstart = function() { return false; };

window.onbeforeunload = function (e) {
  storage.set('R', R, function(error) {
    if (error) throw error;
  });
  storage.set('G', G, function(error) {
    if (error) throw error;
  });
  storage.set('B', B, function(error) {
    if (error) throw error;
  });
}
